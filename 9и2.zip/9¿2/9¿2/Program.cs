﻿using System;
using System.Xml.Serialization;
using ProtoBuf;
using System.Text.Json.Serialization;
using System.IO;
using _9и1.Serialization;

namespace _9и2
{
    internal class Program
    {
        [JsonDerivedType(typeof(Jumpin3m), typeDiscriminator: "Figure Skating")]
        [JsonDerivedType(typeof(Jumpin5m), typeDiscriminator: "Sport Skating")]
        [XmlInclude(typeof(Jumpin3m))]
        [XmlInclude(typeof(Jumpin5m))]
        [ProtoInclude(4, typeof(Jumpin3m))]
        [ProtoInclude(5, typeof(Jumpin5m))]
        [ProtoContract]
        public abstract class Jump
        {
            protected string _name;
            [ProtoMember(1)]
            public string Name
            {
                get { return _name; }
                set { _name = value ?? string.Empty; }
            }
            protected double[] _marks;
            [ProtoMember(2)]
            public double[] Marks
            {
                get { return _marks; }
                set { _marks = value; }
            }
            protected double _summ;
            [ProtoMember(3)]
            public double Summ
            {
                get { return _summ; }
                set { _summ = value; }
            }
            public double SummMarks => _summ;
            public Jump(string name, double[] marks)
            {
                _name = name;
                _marks = marks;
                _summ = 0;
                for (int i = 0; i < Marks.Length; i++) { _summ += _marks[i]; }
            }
            public void Print() => Console.WriteLine("{0}\t {1}", Name, _summ);
            public abstract string Discipline { get; }
        }
        [ProtoContract]
        public class Jumpin3m : Jump
        {
            public override string Discipline => "Прыжки с 3-метровой доски";
            public Jumpin3m(string name, double[] marks) : base(name, marks) { }
        }
        [ProtoContract]
        public class Jumpin5m : Jump
        {
            public override string Discipline => "Прыжки с 5-метровой доски";
            public Jumpin5m(string name, double[] marks) : base(name, marks) { }
        }
            static void Main(string[] args)
            {
                Jump[] sportsman = new Jump[5];
                sportsman[0] = new Jumpin3m("Павлов", new double[] { 0.5, 0, 0, 0.5, 1, 0 });
                sportsman[1] = new Jumpin3m("Попов", new double[] { 1, 1, 0, 0.5, 0, 0.5 });
                sportsman[2] = new Jumpin3m("Ли", new double[] { 0, 1, 1, 0.5, 0, 1 });
                sportsman[3] = new Jumpin5m("Ким", new double[] { 0, 0, 1, 0.5, 0, 1 });
                sportsman[4] = new Jumpin5m("Блоков", new double[] { 1, 1, 1, 0.5, 0, 0 });

                Console.WriteLine("Фамилия\t Набранные баллы");
                foreach (var sportsmen in sportsman)
                    sportsmen.Print();

                Сортировка(sportsman);

                Console.WriteLine();
                Console.WriteLine("Место\tФамилия\t Набранные баллы");
                for (int i = 0; i < sportsman.Length; i++)
                {
                    Console.Write($"{i + 1}\t");
                    sportsman[i].Print();
                }
            MySerializerClass[] serializers = new MySerializerClass[3]
            {
                new JsonMySerializer(),
                new XmlMySerializer(),
                new BinMySerializer()
            };

            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            path = Path.Combine(path, "Sample2");
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            string[] files = new string[3]
            {
                "task.json",
                "task.xml",
                "task.bin"
            };
            for (int i = 0; i < files.Length; i++)
            {
                serializers[i].Write(sportsman, Path.Combine(path, files[i]));
            }
            for (int i = 0; i < files.Length; i++)
            {
                sportsman = serializers[i].Read<Jump[]>(Path.Combine(path, files[i]));
                foreach (Jump info1 in sportsman)
                {
                    info1.Print();
                }
            }
            }

            static void Сортировка(Jump[] sportsman)
            {
                for (int i = 0; i < sportsman.Length - 1; i++)
                {
                    for (int j = i + 1; j < sportsman.Length; j++)
                    {
                        if (sportsman[j].SummMarks > sportsman[i].SummMarks)
                        {
                            Jump temp = sportsman[j];
                            sportsman[j] = sportsman[i];
                            sportsman[i] = temp;
                        }
                    }
                }
            }
    }
}

