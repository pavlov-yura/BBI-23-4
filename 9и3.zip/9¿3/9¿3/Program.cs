﻿using System;
using System.Xml.Serialization;
using ProtoBuf;
using System.Text.Json.Serialization;
using System.IO;
using _9и3.Serialization;

namespace _9и3
{
    [JsonDerivedType(typeof(WomanTeam), typeDiscriminator: "woman")]
    [JsonDerivedType(typeof(ManTeam), typeDiscriminator: "man")]
    [XmlInclude(typeof(WomanTeam))]
    [XmlInclude(typeof(ManTeam))]
    [ProtoInclude(3, typeof(WomanTeam))]
    [ProtoInclude(4, typeof(ManTeam))]
    [ProtoContract]
    public abstract class Team
    {
        protected string name;
        protected int score;
        [ProtoMember(1)]
        public string Name
        {
            get { return name; }
            set { name = value ?? string.Empty; }
        }
        [ProtoMember(2)]
        public int Score
        {
            get { return score; }
            set { score = value; }
        }
        public Team(string name, int score)
        {
            Name = name;
            Score = score;
        }
        public Team()
        {
        }
        public abstract void Print();
    }

    [ProtoContract]
    public class WomanTeam : Team
    {
        public WomanTeam(string name, int score) : base(name, score) { }
        public WomanTeam() : base() { }
        public override void Print()
        {
            Console.WriteLine($"{Name} (Woman): {Score}");
        }
    }

    [ProtoContract]
    public class ManTeam : Team
    {
        public ManTeam(string name, int score) : base(name, score) { }
        public ManTeam() : base() { }
        public override void Print()
        {
            Console.WriteLine($"{Name} (Man): {Score}");
        }
    }

    class Program
    {
        static void PrintResults(Team[] group)
        {
            foreach (var participant in group)
            {
                participant.Print();
            }
        }
        static int TotalScore(Team[] group)
        {
            int total = 0;
            foreach (var participant in group)
            {
                total += participant.Score;
            }
            return total;
        }
        static Team[] FindWinner(Team[] group1, Team[] group2)
        {
            if (TotalScore(group1) > TotalScore(group2)) { return group1; }
            else { return group2; };
        }
        static void Sortirovka(Team[] info)
        {
            for (int i = 0; i < info.Length - 1; i++)
            {
                for (int j = i + 1; j < info.Length; j++)
                {
                    if (info[j].Score > info[i].Score)
                    {
                        Team pomoch = info[j];
                        info[j] = info[i];
                        info[i] = pomoch;
                    }
                }
            }
        }

        static void Main(string[] args)
        {
            WomanTeam[] groupWoman = new WomanTeam[5] { new WomanTeam("Папанкова", 1), new WomanTeam("Поднебесовая", 2), new WomanTeam("Вялко", 3), new WomanTeam("Крайм", 4), new WomanTeam("Ищенко", 5) };
            ManTeam[] groupMan = new ManTeam[5] { new ManTeam("Попов", 9), new ManTeam("Ассадов", 8), new ManTeam("Словеснов", 7), new ManTeam("Андреев", 6), new ManTeam("Клювов", 5) };

            Console.WriteLine("\nРезультаты женской команды:");
            Sortirovka(groupWoman);
            PrintResults(groupWoman);

            Console.WriteLine("\nРезультаты мужской команды:");
            Sortirovka(groupMan);
            PrintResults(groupMan);

            Console.WriteLine($"\nРезультаты команды победителей: ");
            PrintResults(FindWinner(groupWoman, groupMan));


            MySerializerClass[] serializers = new MySerializerClass[3]
            {
                new JsonMySerializer(),
                new XmlMySerializer(),
                new BinMySerializer()
            };

            string path = Environment.CurrentDirectory;
            path = Path.Combine(path, "Sample3");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string[] fileswoman = new string[3]
            {
                "taks3woman.json",
                "taks3woman.xml",
                "taks3woman.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(groupWoman, Path.Combine(path, fileswoman[i]));

            string[] filesman = new string[3]
            {
                "taks3man.json",
                "taks3man.xml",
                "taks3man.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(groupMan, Path.Combine(path, filesman[i]));

            for (int i = 0; i < serializers.Length; i++)
            {
                Console.WriteLine($"From {filesman[i]} and {fileswoman[i]}");
                groupWoman = serializers[i].Read<WomanTeam[]>(Path.Combine(path, fileswoman[i]));
                groupMan = serializers[i].Read<ManTeam[]>(Path.Combine(path, filesman[i]));
                Console.WriteLine("\nРезультаты женской команды:");
                Sortirovka(groupWoman);
                PrintResults(groupWoman);
                Console.WriteLine("\nРезультаты мужской команды:");
                Sortirovka(groupMan);
                PrintResults(groupMan);
                Console.WriteLine($"\nРезультаты команды победителей: ");
                PrintResults(FindWinner(groupWoman, groupMan));
                Console.WriteLine();
            }
        }
    }
}

