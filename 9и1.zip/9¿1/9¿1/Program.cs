﻿using ProtoBuf;
using System.IO;
using System;
using _9и1.Serialization;

namespace _9и1
{
    internal class Program
    {
        [ProtoContract]
        class Info
        {
            protected string _name;
            [ProtoMember(1)]
            public string Name 
            { 
                get { return _name; } 
                set { _name = value ?? string.Empty; } 
            }
            protected string _society;
            [ProtoMember(2)]
            public string Society
            {
                get { return _society; }
                set { _society = value ?? string.Empty; }
            }
            protected int _firstResult;
            [ProtoMember(3)]
            public int FirstResult
            {
                get => _firstResult;
                set => _firstResult = value;
            }
            protected int _secondResult;
            [ProtoMember(4)]
            public int SecondResult
            {
                get => _secondResult;
                set => _secondResult = value;
            }
            protected bool _disqualified;
            [ProtoMember(5)]
            public bool Disqualified
            {
                get => _disqualified;
                set => _disqualified = value;
            }
            public int Summ { get { return _firstResult + _secondResult; } } //публичное свойство
            public Info(string name, string society, int firstResult, int secondResult) //конструктор
            {
                _name = name;
                _society = society;
                _firstResult = firstResult;
                _secondResult = secondResult;
                _disqualified = false;
            }
            public void Disqual() { _disqualified = true; }  // Метод для дисквалификации участника
            public void Print() { if (_disqualified == false) { Console.WriteLine($"{_name}\t{_society}\t{Summ}"); } }
        }
        static void Main(string[] args)
        {
            Info[] info = new Info[5];

            info[0] = new Info("Юрий", "ББИ-23-4", 125, 140);    //ввод данных
            info[1] = new Info("Евгений", "ББИ-23-3", 170, 130);
            info[2] = new Info("Дмитрий", "ББИ-23-2", 105, 150);
            info[3] = new Info("Алиса", "ББИ-23-1", 201, 102);
            info[4] = new Info("Пётр", "ББИ-23-4", 168, 172);

            info[1].Disqual(); //Допустим дисквалифицировали 3-его учатника

            for (int i = 0; i < info.Length - 1; i++)   //сортировка пузырьком по сумме результатов
            {
                for (int j = i + 1; j < info.Length; j++)
                {
                    if (info[i].Summ < info[j].Summ)
                    {
                        Info pomoch = info[j];
                        info[j] = info[i];
                        info[i] = pomoch;
                    }
                }
            }

            Console.WriteLine("Имя\tОбщество\tСумма результатов"); //заголовок таблицы
            for (int i = 0; i < info.Length; i++)  //Вывод таблицы
            {
                info[i].Print();
            }

            MySerializerClass[] serializers = new MySerializerClass[3]
            {
            new JsonMySerializer(),
            new XmlMySerializer(),
            new BinMySerializer(),
            };

            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            path = Path.Combine(path, "AAA1");
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            string[] files = new string[3]
            {
            "task.json",
            "task.xml",
            "task.bin"
            };

            for (int i = 0; i < files.Length; i++)
            {
                serializers[i].Write(info, Path.Combine(path, files[i]));
            }
            for (int i = 0; i < files.Length; i++)
            {
                info = serializers[i].Read<Info[]>(Path.Combine(path, files[i]));
                foreach (Info info1 in info)
                {
                    info1.Print();
                }
            }
        }
    }
}
