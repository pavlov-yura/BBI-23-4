﻿using ProtoBuf;
using System.IO;
using System;
using _9и1.Serialization;

namespace _9и1
{
    [ProtoContract]
    public class Info
    {
        private string name;
        private string society;
        private int firstResult;
        private int secondResult;
        private bool disqualified;
        [ProtoMember(1)]
        public string Name
        {
            get { return name; }
            set { name = value ?? string.Empty; }
        }
        [ProtoMember(2)]
        public string Society
        {
            get { return society; }
            set { society = value ?? string.Empty; }
        }
        [ProtoMember(3)]
        public int FirstResult
        {
            get { return firstResult; }
            set { firstResult = value; }
        }
        [ProtoMember(4)]
        public int SecondResult
        {
            get { return secondResult; }
            set { secondResult = value; }
        }
        [ProtoMember(5)]
        public bool Disqualified
        {
            get { return disqualified; }
            set { disqualified = value; }
        }
        public int Summ { get { return FirstResult + SecondResult; } }
        public Info()
        {
        }
        public Info(string name, string society, int firstResult, int secondResult)
        {
            Name = name;
            Society = society;
            FirstResult = firstResult;
            SecondResult = secondResult;
            Disqualified = false;
        }
        public void Disqual() { Disqualified = true; }
        public void Print() { if (Disqualified == false) { Console.WriteLine($"{Name}\t{Society}\t{Summ}"); } }
    }
    public class Program
    {
        static void Main(string[] args)
        {
            Info[] info = new Info[5];

            info[0] = new Info("Юрий", "ББИ-23-4", 200, 300);
            info[1] = new Info("Евгений", "ББИ-23-3", 100, 200);
            info[2] = new Info("Дмитрий", "ББИ-23-2", 155, 185);
            info[3] = new Info("Алиса", "ББИ-23-1", 101, 204);
            info[4] = new Info("Денис", "ББИ-23-4", 130, 190);

            info[2].Disqual();

            for (int i = 0; i < info.Length - 1; i++)
            {
                for (int j = i + 1; j < info.Length; j++)
                {
                    if (info[i].Summ < info[j].Summ)
                    {
                        Info pomoch = info[j];
                        info[j] = info[i];
                        info[i] = pomoch;
                    }
                }
            }

            MySerializerClass[] serializers = new MySerializerClass[3]
            {
                new JsonMySerializer(),
                new XmlMySerializer(),
                new BinMySerializer()
            };

            string path = Environment.CurrentDirectory;
            path = Path.Combine(path, "Sample1");
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string[] files = new string[3]
            {
                "task1.json",
                "task1.xml",
                "task1.bin"
            };

            for (int i = 0; i < serializers.Length; i++)
                serializers[i].Write(info, Path.Combine(path, files[i]));

            for (int i = 0; i < serializers.Length; i++)
            {
                Console.WriteLine($"From {files[i]}");
                Console.WriteLine("Место\tИмя\tОбщество\tСумма результатов");
                info = serializers[i].Read<Info[]>(Path.Combine(path, files[i]));
                int a = 0;
                for (int j = 0; j < info.Length; j++)
                {
                    if (info[j].Disqualified == false)
                    {
                        Console.Write($"{a + 1}\t");
                        a += 1;
                    }
                    info[j].Print();
                }
                Console.WriteLine();
            }
        }
    }
}
